#pragma once
#include<iostream>
using namespace std;
#include "Node.h"
template <typename T>
class Queue {
public:
	virtual void enqueue(const T&) = 0;
	virtual const T& dequeue() = 0;
	virtual const T& front() = 0;
	virtual bool empty() = 0;
	virtual int size() = 0;
	virtual void clear() = 0;
};
template <typename T>
class LinkedQueue : public Queue<T> {
private:
	int sz;
	Node<T>* head, * tail;
public:
	LinkedQueue(Node<T>* t = nullptr) {
		head = tail = t;
		if (t != nullptr)
			sz = 1;
		else sz = 0;
	}
	~LinkedQueue() {
		clear();
	}
	//enqueue  O(1)
	void enqueue(const T& val) {
		Node<T> n = new Node(val);
		//check if empty
		if (empty())
			head = n;
		else {
			tail->setNext(n);		
		}
		tail = n;
		sz++;
		cout << val << " was enqueued\n";
	}
	//dequeue O(1)
	const T& dequeue() {
		if (empty()) {
			cout << "Qeueue is already empty\n";
			exit(-1);
		}
		//save the val
		T temp = head->getValue();
		Node<T>* c = head;
		head = head->getNext();
		delete c;
		sz--;
		if (head == nullptr)
			tail = nullptr;
		return temp;
	}
	bool empty() {//O(1)
		return sz == 0;//return head==nullptr
	}
	int size() {//O(1)
		return sz;
	}
	const T& front() {
		return head->getValue(); //check if empty then exit(-1);
	}
	void clear() {//O(n)
		//Node<T>* cur = head;
		while (head != nullptr)
			dequeue();
	}
};
template <typename T>
class ArrayQueue : public Queue<T> {
	//we are implementing a circular queue to benefit from empty positions
private:
	int max, head, tail;
	T* list;
public:
	//constructor
	ArrayQueue(const int& m = 10) {
		max = m;
		head = tail = -1;
		list = new T[max]; //create the array
	}
	~ArrayQueue() {
		clear();
	}
	//enqueue operation
	void enqueue(const T& val) { //O(1)
		//adjust if first element
		/*if (head == -1)
		{
			head++; 
			tail++;
			list[head] = val;
			return;
		}*/

		int pos = (tail + 1) % max;//new position where we will be inserting val
		//check if full
		if (pos == head) {
			cout << "Queue is full\n";
			return;
		}
		//add val
		list[pos] = val;
		tail = pos;
		//check if first element
		if (head == -1)
			head = 0;
	}
	//dequeue operation O(1)
	const T& dequeue() {
		if (empty())
		{
			cout << "Queue already empty\n";
			exit(-1);
		}
		//save the value to be removed
		T& t = list[head];
		if (size() == 1) {//if one element still remains in the queue
			
			head = tail = -1;
			
		}
		//more than one element
		//head++;
		else {
			head = (head + 1) % max;
		}
		return t;//return the value		
	}
	const T& front() {
		return list[head]; //if statement for empty case , exit(-1)
	}
	bool empty() {
		return head == -1;
	}
	int size() {
		return (tail + max - head) % max + 1;
	}
	void clear() {
		delete[] list;
		//optional
		tail = head = -1;
	}
};